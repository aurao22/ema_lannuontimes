# ema_lannuontimes coucou titi


## Installation

Créer un environnement virtuel basé sur python 3.9.x et le fichier `requirements.txt`

Installation du griver gecko pour firefox :
- Télécharger le driver pour Firefor : 
- https://github.com/mozilla/geckodriver/releases
- Ajouter dans les variables d'environnement la variable `GECKO_DRIVER_PATH` avec le chemin complet vers le driver

## Exécuter le programme

- Scrapper et stocker les articles de journaux : lancer le script python news_paper_loading.py
- Entrainer le modèle :
- Charger le modèle pré-entrainer et prédire un article :


## liste d'url pour la démo

https://www.elle.fr/People/La-vie-des-people/News/Miley-Cyrus-son-mariage-desastreux-avec-Liam-Hemsworth-4011676
https://www.actugaming.net/god-of-war-ragnarok-sortirait-toujours-en-2022-selon-santa-monica-studios-489652/
https://www.30millionsdamis.fr/actualites/article/22101-deux-lions-et-deux-tigres-ukrainiens-transferes-dans-un-refuge-aux-pays-bas/


## Installation de WordCloud

==== Installation of wordcloud package ====

```
    download wordcloud‑1.8.1‑cp39‑cp39‑win_amd64.whl from http://www.lfd.uci.edu/~gohlke/pythonlibs/#wordcloud
    Copy the file to your current working directory
    Open command prompt from Tools
    python -m pip install wordcloud‑1.8.1‑cp39‑cp39‑win_amd64.whl


Note wordcloud‑1.8.1‑cp39‑cp39‑win_amd64.whl :
cp39 => python 3.9
cp310 => python 3.10
```
